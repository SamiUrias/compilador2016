package Automata;

/**
 * Created by samuel on 13/09/16.
 * Esta clase se encarga de crear un Automata Finito Determinista usando el metodo directo
 */
public class GeneradorDeAutomatasDeterministas {


}
