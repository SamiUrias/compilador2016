package Automata;

/**
 * Created by samuel on 13/09/16.
 */
public class Arbol {
    /*
    * Alfabeto - linked list
    * Nodos - Lista
    * Operadores unarios - linked list
    * Operadores binarios - linked list
    * Nodo <string> padre
    * Caena
    * */

    /*Este atributo contiene la cadena en postfix*/
    private String cadena_postfix = "";

    /**
     * Constructor del Arbol
     * */
    public Arbol(String cadena){

    }
}
