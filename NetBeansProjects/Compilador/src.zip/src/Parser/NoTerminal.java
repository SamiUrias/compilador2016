package Parser;

/**
 * Created by Samuel on 17/11/2016.
 */
public class NoTerminal {
}
