/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lexer;

/**
 *
 * @author Moi
 */
public class Etiqueta {
    public final static int KEYWORD = 255, NUM = 256, IDENT = 257, TRUE = 258, 
            FALSE =259;
}
