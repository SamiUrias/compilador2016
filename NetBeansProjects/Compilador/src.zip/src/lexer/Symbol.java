package lexer;

/**
 * Created by Samuel on 31/10/2016.
 */
public class Symbol {
}
