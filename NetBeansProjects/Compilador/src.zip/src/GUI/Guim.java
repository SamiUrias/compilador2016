package GUI;

import javax.swing.*;

/**
 * Created by Samuel on 25/11/2016.
 */
public class Guim {
    private JPanel panel1;
}
